#!/usr/bin/env bash

. h-manifest.conf

if [[ $(screen -ls xelproxy | grep -Ec "xelproxy.*Dead") > 0 ]]; then screen -wipe; sleep 3; fi
if [[ $(screen -ls xelproxy | grep -c "xelproxy") > 0 ]]; then screen -S xelproxy -X stuff '^C'; sleep 3; fi
if [[ $(screen -ls xelproxy | grep -c "xelproxy") = 0 ]]; then screen -dmS xelproxy -L -Logfile /var/log/miner/custom/xelproxy.log bash -c 'cd proxy; ./xatum-proxy'; echo "Start XEL Proxy..."; sleep 2; fi

./onezerominer $(< ./$CUSTOM_NAME.conf) --api-port=${CUSTOM_API_PORT} --log-file=$CUSTOM_LOG_BASENAME.log
