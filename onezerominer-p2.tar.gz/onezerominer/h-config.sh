#!/usr/bin/env bash
# This code is included in /hive/bin/custom function

[[ -z $CUSTOM_TEMPLATE ]] && echo -e "${YELLOW}CUSTOM_TEMPLATE is empty${NOCOLOR}" && return 1
[[ -z $CUSTOM_URL ]] && echo -e "${YELLOW}CUSTOM_URL is empty${NOCOLOR}" && return 1

conf="--algo xelis --wallet=${CUSTOM_TEMPLATE} "
[[ ! -z ${CUSTOM_PASS} ]] && conf+=" --worker ${CUSTOM_PASS} "
[[ ! -z ${CUSTOM_URL} ]] && conf+=" --pool=${CUSTOM_URL} "
conf+=" ${CUSTOM_USER_CONFIG}"

[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && return 1
echo "$conf" > $CUSTOM_CONFIG_FILENAME

jq --arg CUSTOM_TEMPLATE $CUSTOM_TEMPLATE '.WalletAddress = $CUSTOM_TEMPLATE' /hive/miners/custom/onezerominer/proxy/config.json > /hive/miners/custom/onezerominer/proxy/config0.json && mv /hive/miners/custom/onezerominer/proxy/config0.json /hive/miners/custom/onezerominer/proxy/config.json