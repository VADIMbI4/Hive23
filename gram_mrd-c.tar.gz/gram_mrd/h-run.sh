#!/usr/bin/env bash

. h-manifest.conf
CUSTOM_DIR=`dirname $0`
cd $CUSTOM_DIR

if [[ $(screen -ls qubminer | grep -Ec "qubminer.*Dead") > 0 ]]; then screen -wipe > /var/log/miner/custom/qubminer.log; sleep 2; fi
if [[ $(screen -ls qubminer | grep -c "qubminer") = 0 ]]; then
   [[ -f /var/log/miner/custom/qubminer.log ]] && rm /var/log/miner/custom/qubminer.log
   screen -dmS qubminer -L -Logfile /var/log/miner/custom/qubminer.log bash -c 'cd cpu; ./qli-Client'
   screen -dmS qubstart bash -c 'cd cpu; cpucore=$(grep "amountOfThreads" appsettings.json); sleep 10; cat /var/log/miner/custom/qubminer.log | message success "$(date +%d.%m_%H:%M) Start QUBminer on $cpucore" payload' #'
fi

cd JettonGramGpuMiner
openssl enc -aes-256-cbc -d -pbkdf2 -in Cuda.dll -out CudaCL.dll -k CudaCL.dll
npm install

total_gpu_count=$(gpu-detect NVIDIA)
#$(gpu-stats |jq ".brand" | grep 'nvidia\|amd'|wc -l)

extra=$(<extra.txt)
mode=$(<mode.txt)
echo "GPU Count: $total_gpu_count"
echo "Extra: $extra"
echo "mode: $mode"
pwd

echo "Ready to start" >> exits


CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR



if [ -n "$mode" ]; then

	echo "Single mode"

	counter=0
	while [ $counter -lt $total_gpu_count ]
	do

		while true; 
			do 

				node send_meridian.js $extra --gpu $counter --bin ./pow-miner-cuda | tee -a $CUSTOM_LOG_BASENAME.log

				echo "=======> Died $counter" >> $CUSTOM_LOG_BASENAME.log;
				sleep $[ ( $RANDOM % 10 )  + 3 ]s;
			done &
		
		((counter++))
		sleep 7;

	done

	echo "Ready.."
	rm CudaCL.dll
	wait

else

  echo "Multi mode"
  node send_multigpu.js $extra --bin ./pow-miner-cuda --gpu-count $total_gpu_count | tee -a $CUSTOM_LOG_BASENAME.log
fi





# CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
# [[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

# LD_LIBRARY_PATH=./ ./fuckoff $(< ${CUSTOM_CONFIG_FILENAME})  | tee $CUSTOM_LOG_BASENAME.log

