#!/usr/bin/env bash

. h-manifest.conf

#[[ `ps aux | grep "qethcoreminer" | grep -v grep | wc -l` > 0 ]] &&
#  echo -e "${RED}$CUSTOM_NAME miner is already running${NOCOLOR}" &&
#  exit 1

CUSTOM_LOG_BASEDIR=`dirname "$CUSTOM_LOG_BASENAME"`
[[ ! -d $CUSTOM_LOG_BASEDIR ]] && mkdir -p $CUSTOM_LOG_BASEDIR

conf=`cat $MINER_CONFIG_FILENAME`

if [[ $conf=~';' ]]; then
    conf=`echo $conf | tr -d '\'`
fi

eval "unbuffer ./qethcoreminer ${conf//;/'\;'} --api-bind 127.0.0.1:21373" $@ 2>&1 | tee $CUSTOM_LOG_BASENAME.log
