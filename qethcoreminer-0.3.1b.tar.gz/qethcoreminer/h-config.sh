#!/usr/bin/env bash

mkfile_from_symlink $CUSTOM_CONFIG_FILENAME

local user_config=`echo --report-hashrate --api-port 3434 --HWMON 1 -P $CUSTOM_URL $CUSTOM_USER_CONFIG`

#generating config
echo "$user_config" > $CUSTOM_CONFIG_FILENAME

