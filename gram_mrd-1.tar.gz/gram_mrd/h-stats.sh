
CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

CUSTOM_CONFIG_FILENAME="/hive/miners/custom/${CUSTOM_NAME}/JettonGramGpuMiner/config.txt"
LOG_BASENAME=$CUSTOM_LOG_BASENAME.log

let uptime=`stat --format='%Y' $CUSTOM_LOG_BASENAME.log`-`stat --format='%Y' $CUSTOM_CONFIG_FILENAME`
ac=$(grep -Pc "(?<!not )mined" $CUSTOM_LOG_BASENAME.log) #"

currtime=$(date +%H:%M:%S | sed 's/://' | sed 's/://')
hashtime=$(tail -n 1 $LOG_BASENAME | awk '{print substr($2,1,8);}' | sed 's/://' | sed 's/://') #'
currtime=$(echo "1$currtime")
hashtime=$(echo "1$hashtime")

total_hashrate=0

if [ $hashtime -gt 0 ]
  then
    if [ $currtime -gt 0 ]
      then
        let hashtime=$hashtime+300
        let total_hashrate=$hashtime-$currtime
    fi
fi

total_gpu_count=$(gpu-detect NVIDIA)
local temp=$(jq '.temp' <<< $gpu_stats)
local fan=$(jq '.fan' <<< $gpu_stats)

[[ $cpu_indexes_array != '[]' ]] && #remove Internal Gpus
  temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
  fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)

  for (( i=0; i < $total_gpu_count; i++ )); do
     let t_hs=total_hashrate/$total_gpu_count
     [[ ! -z $t_hs ]] && hs+=\"$t_hs\"" " && khs=`echo $khs $t_hs | awk '{ printf("%.6f", $1 + $2/1) }'`
  done
hash_json=`printf '%s\n' "${hs[@]}" | jq -cs '.'`

ver=1
algo="sha256-ton"

  stats=$(jq -nc \
        --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg hs_units "$hs_units" \
        --argjson temp "$temp" \
        --argjson fan "$fan" \
        --arg uptime "$uptime" \
        --arg algo "$algo" \
        --arg ac "$ac" --arg rj "$rj" \
        --arg ver "$ver" \
        '{$hs, $hs_units, $temp, $fan, $uptime, ar: [$ac, $rj], $algo, $ver}')


[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
