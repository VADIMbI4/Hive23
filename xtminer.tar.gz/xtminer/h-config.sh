####################################################################################
###
### xtminer
###
### Hive integration: Baddy
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/xtminer/h-manifest.conf

conf=""
conf+="--wallet xel:$CUSTOM_TEMPLATE --host $CUSTOM_URL --worker ${CUSTOM_PASS}"

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

