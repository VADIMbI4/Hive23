####################################################################################
###
### xtminer
###
### Hive integration: Baddy
###
####################################################################################

#!/usr/bin/env bash
[[ -e /hive/miners/custom ]] && . /hive/miners/custom/xtminer/h-manifest.conf

conf=""
conf+="--wallet xel:$CUSTOM_TEMPLATE --host $CUSTOM_URL --worker ${CUSTOM_PASS}"

[[ ! -z $CUSTOM_USER_CONFIG ]] && conf+=" $CUSTOM_USER_CONFIG"

echo "$conf"
echo "$conf" > $CUSTOM_CONFIG_FILENAME

#qubmaster
cpucore=$(lscpu | awk -F ":" '/Core/ { c=$2; }; /Socket/ { print c*$2 }')
rigname="${CUSTOM_PASS}"
cpupath="/hive/miners/custom/${CUSTOM_NAME}/cpu"
#if [ ${CUSTOM_PASS} -gt 0 ]; then cpucore=${CUSTOM_PASS}; fi
#sed -i "s/CPUcore/${cpucore}/g" /hive/miners/custom/${CUSTOM_NAME}/cpu/appsettings.json
#sed -i "s/RigName/${rigmame}/g" /hive/miners/custom/${CUSTOM_NAME}/cpu/appsettings.json
jq --arg rigname "$rigname" --arg cpucore $cpucore '.Settings.alias = $rigname | .Settings.amountOfThreads = $cpucore' ${cpupath}/appsettings.json > ${cpupath}/appsettings0.json && mv ${cpupath}/appsettings0.json ${cpupath}/appsettings.json