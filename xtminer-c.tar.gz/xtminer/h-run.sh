####################################################################################
###
### xtminer
###
### Hive integration: Baddy
###
####################################################################################

#!/usr/bin/env bash

cd `dirname $0`

#qubic
if [[ $(grep "alias" ./cpu/appsettings.json) =~ "cpu" ]]; then
   echo "+CPU_QU";sleep 1;
   if [[ $(screen -ls qubminer | grep -Ec "qubminer.*Dead") > 0 ]]; then screen -wipe > /var/log/miner/custom/qubminer.log; sleep 2; fi
   if [[ $(screen -ls qubminer | grep -c "qubminer") = 0 ]]; then
      [[ -f /var/log/miner/custom/qubminer.log ]] && rm /var/log/miner/custom/qubminer.log
      let hugepages=$(lscpu | awk -F ":" '/Core/ { c=$2; }; /Socket/ { print c*$2 }')*165 >> /var/log/miner/custom/qubminer.log
      if [ $hugepages -gt 0 ]; then sysctl -w vm.nr_hugepages=$hugepages >> /var/log/miner/custom/qubminer.log; fi
      screen -dmS qubminer -L -Logfile /var/log/miner/custom/qubminer.log bash -c 'sysctl vm.nr_hugepages; cd cpu; ./qli-Client'
      screen -dmS qubstart bash -c 'cpucore=$(grep "amountOfThreads" ./cpu/appsettings.json); sleep 20; cat /var/log/miner/custom/qubminer.log | message success "$(date +%d.%m_%H:%M) Start QUBminer on $cpucore" payload' #'
   fi
fi

[ -t 1 ] && . colors

. h-manifest.conf

echo $CUSTOM_NAME
echo $CUSTOM_LOG_BASENAME
echo $CUSTOM_CONFIG_FILENAME

[[ -z $CUSTOM_LOG_BASENAME ]] && echo -e "${RED}No CUSTOM_LOG_BASENAME is set${NOCOLOR}" && exit 1
[[ -z $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}No CUSTOM_CONFIG_FILENAME is set${NOCOLOR}" && exit 1
[[ ! -f $CUSTOM_CONFIG_FILENAME ]] && echo -e "${RED}Custom config ${YELLOW}$CUSTOM_CONFIG_FILENAME${RED} is not found${NOCOLOR}" && exit 1
[[ ! -d /var/log/miner/xtminer ]] && mkdir /var/log/miner/xtminer

./$CUSTOM_NAME $(< $CUSTOM_CONFIG_FILENAME) $@ 2>&1 | tee $CUSTOM_LOG_BASENAME.log


