#!/usr/bin/env bash

. h-manifest.conf

#######################
# Functions
#######################

get_cards_hashes(){
  #Device #0: 173.97 KHs |Device #1: 184.21 KHs |Device #2: 190.35 KHs |Device #3: 186.25 KHs |Device #4: 147.37 KHs |Device #5: 147.37 KHs |Device #6: 151.97 KHs | Total: 1.18 MHs

  hs=''
  khs=0
  local t_hs=-1
  local i=0;
  for (( i=0; i < ${GPU_COUNT}; i++ )); do
    let "fi2=i+2"
    t_hs=`cat $log_name | grep -a "Total:" | tail -n 1 | cut -d ":" -f$fi2 | cut -d "K" -f1 | sed 's/ //g' | sed 's/K//g' | awk '{ printf("%.3f", $1 + $2/1000) }'`
    [[ ! -z $t_hs ]] && hs+=\"$t_hs\"" " && khs=`echo $khs $t_hs | awk '{ printf("%.6f", $1 + $2/1) }'`
  done
}

get_miner_uptime(){
  local a=0
  let a=`stat --format='%Y' $log_name`-`stat --format='%Y' $conf_name`
  echo $a
}

get_log_time_diff(){
  local a=0
  let a=`date +%s`-`stat --format='%Y' $log_name`
  echo $a
}

#######################
# MAIN script body
#######################

local log_dir=`dirname "$MINER_LOG_BASENAME"`

cd "$log_dir"
local log_name=$(ls -t --color=never | head -1)
log_name="$CUSTOM_LOG_BASENAME.log"
local ver=`miner_ver`
local conf_name="/hive/custom/$CUSTOM_NAME/$CUSTOM_NAME.conf"

local temp=$(jq '.temp' <<< $gpu_stats)
local fan=$(jq '.fan' <<< $gpu_stats)

[[ $cpu_indexes_array != '[]' ]] && #remove Internal Gpus
  temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
  fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)

# Calc log freshness
local diffTime=$(get_log_time_diff)
local maxDelay=120

local algo="octopus"

GPU_COUNT=`echo $(gpu-detect NVIDIA) | awk '{ printf($1 + $2) }'`

# If log is fresh the calc miner stats or set to null if not
if [ "$diffTime" -lt "$maxDelay" ]; then
  get_cards_hashes # hashes array
  local hs_units='hs' # hashes utits
  local uptime=$(get_miner_uptime) # miner uptime

  # A/R shares by pool
  local ac=`cat $log_name  | grep -a "Found a solution with target" | wc -l`

# make JSON
  stats=$(jq -nc \
        --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg hs_units "$hs_units" \
        --argjson temp "$temp" \
        --argjson fan "$fan" \
        --arg uptime "$uptime" \
        --arg algo "$algo" \
        --arg ac "$ac" --arg rj "$rj" \
        --arg ver "$ver" \
        '{$hs, $hs_units, $temp, $fan, $uptime, ar: [$ac, $rj], $algo, $ver}')
else
  stats=""
  khs=0
fi

# debug output
##echo temp:  $temp
##echo fan:   $fan
#echo stats: $statsOD
#echo khs:   $khs
