#!/usr/bin/env bash

#set -ex

. colors

khs=0
stats=
algo='bufius'

#stats_raw='{"air":[3,2,1],"miner_name":"aleo1to","mode":"pool","threads":[{"bus":1,"hr":1505.0,"id":0},{"bus":2,"hr":832.0,"id":1},{"bus":3,"hr":257.0,"id":2},{"bus":4,"hr":0.0,"id":3},{"bus":5,"hr":0.0,"id":4},{"bus":13,"hr":1933.0,"id":5},{"bus":14,"hr":0.0,"id":6},{"bus":15,"hr":0.0,"id":7}],"units":"cs","uptime":"51.512555596s","version":"0.2.3","version_hash":"15b7481"}'
stats_raw=`curl -s --connect-timeout 5 http://127.0.0.1:32159`

if [[ $? -ne 0 || -z $stats_raw ]]; then
  echo -e "${YELLOW}Failed to read stat from 127.0.0.1:32159${NOCOLOR}"
else
  readarray -t arr < <(echo "$stats_raw" | jq -cr '.version, .uptime, .units, [.air[0], .air[2], .air[1]], [.threads[].hr], [.threads[].bus], .version_hash, ([.threads[].hr]|add/1000) ' 2>/dev/null)
  #echo "#debug: ${arr[@]}"
  version="${arr[0]}"
  uptime="${arr[1]/s/}"
  units="${arr[2]}"
  air="${arr[3]}"
  hs="${arr[4]}"
  bus_numbers="${arr[5]}"
  verhash="${arr[6]}"
  khs="${arr[7]}"

  #khs=`echo "$hs" | jq -r 'add/1000'`
  [[ $verhash != "null" ]] && version="$version-$verhash"
  hs_units="${units/cs/hs}" # cs -> hs

  readarray -t gpu_stats < <(jq --slurp -r -c '.[] | .busids, .brand, .temp, .fan | join(" ")' $GPU_STATS_JSON 2>/dev/null)
  busids=(${gpu_stats[0]})
  brands=(${gpu_stats[1]})
  temps=(${gpu_stats[2]})
  fans=(${gpu_stats[3]})
  count=${#busids[@]}

  # match by busid
  readarray -t busid_arr < <(echo "$bus_numbers" | jq -rc '.[]') # 1 2 3
  fan_arr=()
  temp_arr=()
  for(( i=0; i < count; i++ )); do
    [[ "${brands[i]}" != "nvidia" ]] && continue
    [[ ! "${busids[i]}" =~ ^([A-Fa-f0-9]+): ]] && continue
    [[ ! " ${busid_arr[@]} " =~ \ $((16#${BASH_REMATCH[1]}))\  ]] && continue
    temp_arr+=(${temps[i]})
    fan_arr+=(${fans[i]})
  done

  fan=`printf '%s\n' "${fan_arr[@]}"  | jq -cs '.'`
  temp=`printf '%s\n' "${temp_arr[@]}"  | jq -cs '.'`

  stats=$(jq -nc --arg uptime "$uptime" \
                 --arg algo "$algo" \
                 --arg hs_units "$hs_units" \
                 --arg khs "$khs" \
                 --arg ver "$version" \
                 --argjson temp "$temp" \
                 --argjson fan "$fan" \
                 --argjson bus_numbers "$bus_numbers" \
                 --argjson hs "$hs" \
                 --argjson ar "$air" \
                 '{"total_khs": $khs|tonumber, $hs, $hs_units, "uptime":$uptime|tonumber|floor, $algo, $ar, $temp, $fan, $bus_numbers, $ver}')

  #echo "#debug: $stats"
fi
