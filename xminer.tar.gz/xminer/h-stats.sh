
CUSTOM_DIR=$(dirname "$BASH_SOURCE")

. $CUSTOM_DIR/h-manifest.conf

CUSTOM_CONFIG_FILENAME="/hive/miners/custom/${CUSTOM_NAME}/config.txt"
LOG_BASENAME=$CUSTOM_LOG_BASENAME.log

let uptime=`stat --format='%Y' $CUSTOM_LOG_BASENAME.log`-`stat --format='%Y' $CUSTOM_CONFIG_FILENAME`

khscpu=$(tail -n1  $LOG_BASENAME | awk -F '|' '{print $5}' | sed -r "s/\x1B\[(([0-9]{1,2})?(;)?([0-9]{1,2})?)?[m,K,H,f,J]//g");
if [[ $khscpu =~ "KH/s" ]]; then khscpu=$(echo $khscpu | awk '{print substr($1,1)}'); else khscpu=$(echo $khscpu | awk '{print $1/1000}'); fi #"

total_hashrate=$(echo $khscpu | awk '{print $1*1000}')

total_gpu_count=$(gpu-detect NVIDIA)
local temp=$(jq '.temp' <<< $gpu_stats)
local fan=$(jq '.fan' <<< $gpu_stats)

[[ $cpu_indexes_array != '[]' ]] && #remove Internal Gpus
  temp=$(jq -c "del(.$cpu_indexes_array)" <<< $temp) &&
  fan=$(jq -c "del(.$cpu_indexes_array)" <<< $fan)

  let t_hs=total_hashrate/$total_gpu_count

  t_hs=$(echo $t_hs | awk '{print $1/1000}')
  for (( i=0; i < $total_gpu_count; i++ )); do
         [[ ! -z $t_hs ]] && hs+=\"$t_hs\"" " && khs=`echo $khs $t_hs | awk '{ printf("%.6f", $1 + $2/1) }'`

  done

hash_json=`printf '%s\n' "${hs[@]}" | jq -cs '.'`

ver=1
algo="xevan"
hs_units="khs"

ac=$(tail -n1 $LOG_BASENAME | awk -F '|' '{print $3}' | sed -r "s/\x1B\[(([0-9]{1,2})?(;)?([0-9]{1,2})?)?[m,K,H,f,J]//g" | awk '{print substr($2,1)}')
rj=$(tail -n1 $LOG_BASENAME | awk -F '|' '{print $4}' | sed -r "s/\x1B\[(([0-9]{1,2})?(;)?([0-9]{1,2})?)?[m,K,H,f,J]//g" | awk '{print substr($2,1)}')

  stats=$(jq -nc \
        --argjson hs "`echo ${hs[@]} | tr " " "\n" | jq -cs '.'`" \
        --arg hs_units "$hs_units" \
        --argjson temp "$temp" \
        --argjson fan "$fan" \
        --arg uptime "$uptime" \
        --arg algo "$algo" \
        --arg ac "$ac" --arg rj "$rj" \
        --arg ver "$ver" \
        '{$hs, $hs_units, $temp, $fan, $uptime, ar: [$ac, $rj], $algo, $ver}')


[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"
